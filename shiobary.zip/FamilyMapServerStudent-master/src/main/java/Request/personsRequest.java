package Request;

import Model.AuthToken;

/**
 * Creates personsRequest with authToken. User will pass authtoken to retrieve data for all person object connected to the user.
 */
public class personsRequest {
    AuthToken token;
}
