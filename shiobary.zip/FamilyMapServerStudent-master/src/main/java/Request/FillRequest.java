package Request;

public class FillRequest {
    String username;
    Integer numGen;

    public FillRequest(String username, Integer numGen) {
        this.username = username;
        this.numGen = numGen;
    }
}
