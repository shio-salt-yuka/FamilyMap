package Model;

public class name {
    String [] data;
    String snames;
    String mnames;
    String fnames;

    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }

}
