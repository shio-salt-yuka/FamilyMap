package Model;

import java.util.ArrayList;

public class locationsList {
    ArrayList<location> data;


    public ArrayList<location> getData() {
        return data;
    }
}
